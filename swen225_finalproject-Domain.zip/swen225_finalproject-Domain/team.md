| Module     | Team Member Name | Team Member gitlab account |
| ---------- | ---------------- | -------------------------- |
| Domain     | Chaitanya Gautam | gautamchai                 |
| App        | Emmanuel De Vera | deveremma                  |
| Render     | Arnav Dogra      | dograarna                  |
| Persistency| Alvien Salvador  | salvadalvi                 |
| Recorder   | Ricky Fong       | fongrick                   |
| Fuzz       | Takoda Teal      | tealtako                   |
