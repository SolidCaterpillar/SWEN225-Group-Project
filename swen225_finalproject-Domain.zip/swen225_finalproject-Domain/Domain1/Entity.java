public interface Entity
{
    public Coord getLocation();
}
