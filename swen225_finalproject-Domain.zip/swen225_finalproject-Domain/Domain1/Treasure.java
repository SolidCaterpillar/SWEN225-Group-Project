public class Treasure implements Entity{
    @Override
    public Coord getLocation() {
        return null;
    }
}
