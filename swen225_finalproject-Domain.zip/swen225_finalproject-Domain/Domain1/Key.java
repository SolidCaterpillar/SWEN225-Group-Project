public class Key implements Entity{

    protected Coord location;


    @Override
    public Coord getLocation() {
        return null;
    }
}
