import javax.swing.*;

public class KeyTile extends WallTile{

    public KeyTile(Coord location, WallType wallType, JPanel gui) {
        super(location, wallType, gui);
    }


}
