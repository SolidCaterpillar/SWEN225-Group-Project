public class testClass {
    public testClass(){}

    public static void main(String... args){
        Board test = new Board(0,null);
    }
}
