public enum TileType {
    WALL,
    FREE,
    KEY,
    LOCKED_DOOR,
    INFO_FIELD,
    TREASURE,
    EXIT_LOCK,
    PLAYER,
    EXIT
}