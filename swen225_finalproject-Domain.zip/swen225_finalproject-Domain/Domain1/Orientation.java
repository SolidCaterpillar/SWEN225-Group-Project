public enum Orientation { //both player and enemy would us orientationt to change sprites relative to direction moving in
        NORTH,
        SOUTH,
        EAST,
        WEST
}
